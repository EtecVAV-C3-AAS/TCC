from flask import Blueprint
bp_principal = Blueprint('principal', __name__, template_folder='../templates')
